package com.cts.cts2020;



public interface Greetable {

	void greet() ;

	// String greetParam(String str) ;



}