package com.cts.cts2020;

import java.util.*;

public class TestHashSet {

	



	public static void main(String[] args) {

		/*
		Person p1 = new Person("Monu","Agar");

		Person p2 = new Person("Sonu","Agar");

		Person p3 = new Person("Renu","Agar");

		Person p4 = new Person("Asit","Gupta");

		Person p5 = new Person("Mohit","Gupta");

		

		System.out.println(p4.equals(p5));

		

		Set<Person> pSet = new TreeSet<>();

		pSet.add(p1);

		pSet.add(p2);

		pSet.add(p3);

		pSet.add(p4);

		pSet.add(p5);

		

		for(Person p:pSet) {

			System.out.println(p);

			

		}
		*/
		
		Worker w1= new Worker(200l,200.0,"Monu","Agar","M");
		Worker w2= new Worker(202l,300.0,"Mohit","Agar","M");
		Worker w3= new Worker(203l,600.0,"Sonu","Har","M");
		Worker w4= new Worker(201l,400.0,"Monu","Kapoor","M");

		Set<Worker> wSet = new TreeSet<>();

		wSet.add(w1);

		wSet.add(w2);

		wSet.add(w3);

		wSet.add(w4);

			
		Iterator<Worker> itr=wSet.iterator();
		
		while(itr.hasNext()) {

			System.out.println(itr.next());

			

		}
	

	}



}