package com.cts.cts2020.report;

import com.cts.cts2020.Contractor;

public class EmployeeReports {

	public static void main(String[] args) {
		Contractor cont2 = new Contractor();
		// cont2.lname = "no visib";

	}

}
