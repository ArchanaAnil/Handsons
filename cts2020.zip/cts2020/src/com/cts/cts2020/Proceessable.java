package com.cts.cts2020;

public interface Proceessable {

	String process(Person pr, Car c);


}
