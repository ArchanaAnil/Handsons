package com.cts.cts2020;

public class NoAadharException extends Exception {

}
