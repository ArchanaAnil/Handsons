package com.cts.cts2020;

public class NoNameMatchException extends Exception {

	NoNameMatchException(String message)
	{
		super(message);
	}
}
