package com.cts.cts2020;

public class Departments {
	
	int id;
	String name;
	int managerId;
	int locationId;
	public Departments(int id, String name, int managerId, int locationId) {
		super();
		this.id = id;
		this.name = name;
		this.managerId = managerId;
		this.locationId = locationId;
	}
	public Departments() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public int getManagerId() {
		return managerId;
	}
	public int getLocationId() {
		return locationId;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}
	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}
	
	

}
