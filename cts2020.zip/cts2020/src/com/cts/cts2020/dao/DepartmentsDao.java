package com.cts.cts2020.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cts.cts2020.Departments;


public class DepartmentsDao {

	public Connection getConnection(){

		Connection con = null;

		try {

			// Class.forName("com.mysql.jdbc.Driver");  
			con = DriverManager.

					getConnection("jdbc:mysql://localhost:3306/hr", "root", "Priyaanil@123");

		} catch (SQLException e1) {

			e1.printStackTrace();

		}

		 return con;

	}

	

		
	
  public List<Departments> getAllDepartments(){

		
	  Connection con = getConnection();

		Statement st = null;

		List<Departments> dList = new ArrayList<>();

		try {

			st = con.createStatement();

			ResultSet rs = st.executeQuery("select * from departments");

			while(rs.next()) {

				System.out.println(rs.getInt(1));

				System.out.println(rs.getString(2));

				// System.out.println(rs.getString(3));

				// System.out.println(rs.getDate("hire_date"));

				

				Departments dep = new Departments();

				dep.setName(rs.getString(2));

				dep.setId(rs.getInt(1));

				dList.add(dep);		

			}

		} catch (SQLException e) {

				e.printStackTrace();

		} finally {

			try {

				con.close();

				st.close();

			} catch (SQLException e) {

				// TODO Auto-generated catch block

				e.printStackTrace();

			}
		}


		return dList;
		}
	
	
}
