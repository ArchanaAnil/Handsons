package com.cts.cts2020;

public class IllegibleNameException extends Exception {

}
