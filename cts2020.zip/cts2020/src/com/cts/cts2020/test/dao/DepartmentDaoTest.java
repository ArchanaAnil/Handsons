package com.cts.cts2020.test.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.cts.cts2020.Departments;
import com.cts.cts2020.dao.DepartmentsDao;

public class DepartmentDaoTest {

	

	// write a test case for getAllDepartments

	@Test

	void testGetAllDepartments() {

		DepartmentsDao empdao = new DepartmentsDao();

		List<Departments> l = empdao.getAllDepartments();

		assertEquals(28, l.size());

	}

}
