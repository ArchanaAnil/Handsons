package com.cts.cts2020;

import java.util.Scanner;
import java.util.function.Predicate;

public class EligibilityToVote {

	public static void main(String[] args) {

		boolean res;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter age:");
		int age=sc.nextInt();
		Predicate<Integer> check=i->(i<18);
		res=check.test(age);
		if(res)
			System.out.println("Cannot vote");
		else
			System.out.println("Eligible to Vote");
	}

}
